"""Make certificate admin class available from package root."""
from .py.cert_admin import CertAdmin
